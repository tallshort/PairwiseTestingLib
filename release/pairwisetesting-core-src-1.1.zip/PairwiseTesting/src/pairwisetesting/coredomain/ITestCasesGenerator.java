package pairwisetesting.coredomain;

public interface ITestCasesGenerator {

	String generate(MetaParameter mp, String[][] testData);

}
